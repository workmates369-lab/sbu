package com.example.smartpantry.models;

import java.io.Serializable;

/**
 * RecipeIngredient represents an ingredient required for a specific recipe.
 *
 * Fields:
 * - id: Unique identifier in recipe_ingredients table
 * - recipeId: Foreign key reference to the recipe
 * - ingredientName: Name of the ingredient (e.g., "Chicken")
 * - requiredQuantity: Amount needed (e.g., 500)
 * - unit: Measurement unit (e.g., "g", "pieces")
 */
public class RecipeIngredient implements Serializable {
    private int id;
    private int recipeId;
    private String ingredientName;
    private double requiredQuantity;
    private String unit;

    /**
     * Default constructor
     */
    public RecipeIngredient() {
    }

    /**
     * Constructor with all fields
     */
    public RecipeIngredient(int id, int recipeId, String ingredientName, double requiredQuantity, String unit) {
        this.id = id;
        this.recipeId = recipeId;
        this.ingredientName = ingredientName;
        this.requiredQuantity = requiredQuantity;
        this.unit = unit;
    }

    /**
     * Constructor without ID (for new ingredients)
     */
    public RecipeIngredient(int recipeId, String ingredientName, double requiredQuantity, String unit) {
        this.recipeId = recipeId;
        this.ingredientName = ingredientName;
        this.requiredQuantity = requiredQuantity;
        this.unit = unit;
    }

    /**
     * Constructor with just the ingredient details (for display purposes)
     */
    public RecipeIngredient(String ingredientName, double requiredQuantity, String unit) {
        this.ingredientName = ingredientName;
        this.requiredQuantity = requiredQuantity;
        this.unit = unit;
    }

    // Getters
    public int getId() {
        return id;
    }

    public int getRecipeId() {
        return recipeId;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public double getRequiredQuantity() {
        return requiredQuantity;
    }

    public String getUnit() {
        return unit;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setRecipeId(int recipeId) {
        this.recipeId = recipeId;
    }

    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }

    public void setRequiredQuantity(double requiredQuantity) {
        this.requiredQuantity = requiredQuantity;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "RecipeIngredient{" +
                "id=" + id +
                ", recipeId=" + recipeId +
                ", ingredientName='" + ingredientName + '\'' +
                ", requiredQuantity=" + requiredQuantity +
                ", unit='" + unit + '\'' +
                '}';
    }
}
