# Smart Pantry Manager

A complete Android application for managing home ingredients and discovering recipes you can prepare with your current pantry. Built with Java, Android Studio, SQLite, and RecyclerView.

## Project Status

**Current Stage: Stage 1 - Project Structure & Navigation Setup**

This is a university-level Mobile App Development 700 practical assignment. The application is being built incrementally through multiple stages.

### Completed Stages:
- ✅ Stage 1: Android Studio project structure, Activities, XML layouts, model classes

### Upcoming Stages:
- Stage 2: XML layout refinement and styling
- Stage 3: Complete model classes with business logic
- Stage 4: SQLite database implementation with DatabaseHelper
- Stage 5: Pantry CRUD operations and data persistence
- Stage 6: RecyclerView adapters for pantry display
- Stage 7: Recipe database seeding with 20+ recipes
- Stage 8: Strict recipe matching engine (RecipeMatcher)
- Stage 9: Suggested Recipes screen implementation
- Stage 10: Recipe Detail screen
- Stage 11: Settings screen with preferences
- Stage 12: Input validation and error handling
- Stage 13: Testing and debugging
- Stage 14: UI refinements and polish
- Stage 15: Documentation and final submission

## Application Concept

Smart Pantry Manager helps users:
1. **Manage Ingredients** - Add, edit, delete items in your pantry with quantities and expiry dates
2. **Discover Recipes** - See which recipes you can cook with your current ingredients
3. **Strict Matching** - Only recipes where you have EVERY ingredient in sufficient quantity are suggested

### Most Important Business Rule

> A recipe may ONLY appear in "Suggested Recipes" when the user's pantry contains EVERY ingredient required by that recipe AND contains at least the required quantity.

**Example:**
- Recipe: Chicken Pasta (requires: Chicken 500g, Pasta 250g, Tomato 2, Onion 1)
- Pantry: Chicken 500g, Pasta 250g, Tomato 2, Onion 0
- Result: Chicken Pasta is NOT suggested (missing onion)

## Features

### Current Implementation (Stage 1)
- ✅ Project structure with proper package organization
- ✅ Five main Activities: Pantry, Add/Edit, Recipes, Recipe Detail, Settings
- ✅ Database, models, adapters, and utilities packages
- ✅ All required XML layouts
- ✅ Bottom navigation for multi-screen navigation
- ✅ Material Design styling with color scheme

### Features to Come
- Database CRUD operations (Create, Read, Update, Delete)
- Persistent SQLite storage
- 20+ seeded recipes
- Strict recipe matching engine
- RecyclerView with custom adapters
- Expiry date tracking and alerts
- Input validation with error messages
- Settings management

## Technology Stack

- **Language**: Java (Android Framework)
- **IDE**: Android Studio
- **Database**: SQLite with SQLiteOpenHelper
- **UI Components**: RecyclerView, CardView, Material Design
- **Layouts**: XML
- **Navigation**: Android Intents & Bottom Navigation
- **Version Control**: Git/GitHub

## Project Structure

```
SmartPantryManager/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/smartpantry/
│   │   │   ├── activities/
│   │   │   │   ├── MainActivity.java
│   │   │   │   ├── AddEditIngredientActivity.java
│   │   │   │   ├── SuggestedRecipesActivity.java
│   │   │   │   ├── RecipeDetailActivity.java
│   │   │   │   └── SettingsActivity.java
│   │   │   ├── adapters/
│   │   │   │   ├── PantryAdapter.java (coming soon)
│   │   │   │   └── RecipeAdapter.java (coming soon)
│   │   │   ├── database/
│   │   │   │   └── DatabaseHelper.java (coming soon)
│   │   │   ├── models/
│   │   │   │   ├── PantryItem.java
│   │   │   │   ├── Recipe.java
│   │   │   │   └── RecipeIngredient.java
│   │   │   └── utils/
│   │   │       ├── RecipeMatcher.java (coming soon)
│   │   │       ├── UnitConverter.java (coming soon)
│   │   │       └── IngredientNormalizer.java (coming soon)
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml
│   │   │   │   ├── activity_add_edit_ingredient.xml
│   │   │   │   ├── activity_suggested_recipes.xml
│   │   │   │   ├── activity_recipe_detail.xml
│   │   │   │   ├── activity_settings.xml
│   │   │   │   ├── item_pantry.xml
│   │   │   │   ├── item_recipe.xml
│   │   │   │   └── item_recipe_ingredient.xml
│   │   │   ├── values/
│   │   │   │   ├── strings.xml
│   │   │   │   ├── colors.xml
│   │   │   │   └── styles.xml
│   │   │   ├── menu/
│   │   │   │   └── bottom_navigation_menu.xml
│   │   │   └── drawable/
│   │   │       └── spinner_background.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── .gitignore
└── README.md
```

## Getting Started

### Prerequisites
- Android Studio (latest version recommended)
- Android SDK (API Level 24 or higher)
- Java Development Kit (JDK 8 or higher)
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/smart-pantry-manager.git
   cd SmartPantryManager
   ```

2. **Open in Android Studio**
   - Launch Android Studio
   - Select "Open an Existing Project"
   - Navigate to the SmartPantryManager directory
   - Click "Open"

3. **Sync Gradle**
   - Android Studio will prompt to sync gradle files
   - Click "Sync Now"
   - Wait for the build to complete

4. **Create or Start an Emulator**
   - Click "Tools" → "Device Manager"
   - Create a new virtual device or start an existing one
   - Select a device with API Level 24 or higher

5. **Run the Application**
   - Click "Run" → "Run 'app'"
   - Select your emulator
   - Wait for the app to build and deploy

## Testing (Current Stage)

### Stage 1 Testing

**Test 1: Verify Project Opens**
1. Open the project in Android Studio
2. Let Gradle sync complete
3. Verify no red error marks in code files

**Test 2: Verify App Launches**
1. Click Run → Run 'app'
2. Select your emulator
3. App should launch and show the Pantry screen with empty state

**Test 3: Verify Navigation**
1. Look at the bottom navigation bar
2. Verify three tabs: Pantry, Recipes, Settings (currently non-functional)
3. Click the Floating Action Button (+)
4. Verify it doesn't crash (no implementation yet)

**Expected Results:**
- App opens without crashing
- Main activity displays with empty pantry message
- UI is clean and responsive
- Bottom navigation is visible
- FAB (floating action button) is present

### Known Limitations (Stage 1)
- No database functionality yet
- Navigation buttons don't work (will be implemented in later stages)
- Add ingredient button shows no dialog (implementation pending)
- No data persistence
- No recipe matching yet

## Development Progress

| Stage | Feature | Status |
|-------|---------|--------|
| 1 | Project Structure & Navigation | ✅ Complete |
| 2 | XML Layout Refinement | ⏳ Pending |
| 3 | Model Classes | ⏳ Pending |
| 4 | Database Setup | ⏳ Pending |
| 5 | Pantry CRUD | ⏳ Pending |
| 6 | RecyclerView Adapters | ⏳ Pending |
| 7 | Recipe Seeding | ⏳ Pending |
| 8 | Recipe Matching Engine | ⏳ Pending |
| 9 | Suggested Recipes Screen | ⏳ Pending |
| 10 | Recipe Detail Screen | ⏳ Pending |
| 11 | Settings Screen | ⏳ Pending |
| 12 | Validation & Error Handling | ⏳ Pending |
| 13 | Testing & Debugging | ⏳ Pending |
| 14 | UI Polish | ⏳ Pending |
| 15 | Documentation | ⏳ Pending |

## Git Commit History

As the project develops, commits will follow this pattern:
1. Initialize Android Studio Java project
2. Create application layouts
3. Add PantryItem model
4. Implement SQLite database
5. Implement pantry CRUD
6. Add RecyclerView pantry adapter
7. Add recipe database and seed data
8. Implement recipe matching engine
9. Add Suggested Recipes screen
10. Add Recipe Detail screen
11. Add Settings screen
12. Add validation and error handling
13. Improve UI and navigation
14. Test strict matching logic
15. Update README documentation

## Database Schema (Coming Soon)

### Tables to be created:

**pantry**
- id (INTEGER PRIMARY KEY AUTOINCREMENT)
- name (TEXT)
- quantity (REAL)
- unit (TEXT)
- expiry_date (TEXT)

**recipes**
- id (INTEGER PRIMARY KEY AUTOINCREMENT)
- name (TEXT)
- description (TEXT)
- instructions (TEXT)

**recipe_ingredients**
- id (INTEGER PRIMARY KEY AUTOINCREMENT)
- recipe_id (INTEGER FOREIGN KEY)
- ingredient_name (TEXT)
- required_quantity (REAL)
- unit (TEXT)

**settings**
- id (INTEGER PRIMARY KEY AUTOINCREMENT)
- expiry_alerts (BOOLEAN)

## Contributors

- Student: [Your Name]
- Course: Mobile App Development 700
- Institution: [Your University]

## License

This project is created for educational purposes as part of a university assignment.

## Support

For issues or questions, please open an issue in the GitHub repository or contact the developer.

---

**Last Updated**: Stage 1
**Next Update**: Stage 2 - XML Layout Refinement
